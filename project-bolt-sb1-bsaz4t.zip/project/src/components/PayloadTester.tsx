import React, { useState } from 'react';
import { Send } from 'lucide-react';

interface PayloadTesterProps {
  onPayloadSubmit: (payload: string) => void;
}

export default function PayloadTester({ onPayloadSubmit }: PayloadTesterProps) {
  const [payload, setPayload] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (payload.trim()) {
      onPayloadSubmit(payload);
      setPayload('');
    }
  };

  return (
    <div className="bg-gray-900/50 backdrop-blur p-6 rounded-xl border border-gray-800">
      <h3 className="text-lg font-semibold text-gray-200 mb-4">Payload Testing</h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <textarea
            value={payload}
            onChange={(e) => setPayload(e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 rounded-lg p-3 text-gray-300 focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            rows={3}
            placeholder="Enter payload to test..."
          />
        </div>
        <button
          type="submit"
          className="inline-flex items-center px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg transition-colors"
        >
          <Send className="w-4 h-4 mr-2" />
          Test Payload
        </button>
      </form>
    </div>
  );
}