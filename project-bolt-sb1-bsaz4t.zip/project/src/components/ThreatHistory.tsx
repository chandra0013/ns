import React from 'react';
import type { Threat } from '../types';

interface ThreatHistoryProps {
  threats: Threat[];
}

export default function ThreatHistory({ threats }: ThreatHistoryProps) {
  return (
    <div className="bg-gray-900/50 backdrop-blur p-6 rounded-xl border border-gray-800">
      <h3 className="text-lg font-semibold text-gray-200 mb-4">Threat History</h3>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-left text-gray-400 text-sm">
              <th className="pb-3">Timestamp</th>
              <th className="pb-3">Type</th>
              <th className="pb-3">Payload</th>
              <th className="pb-3">Status</th>
            </tr>
          </thead>
          <tbody className="text-gray-300">
            {threats.map((threat) => (
              <tr key={threat.id} className="border-t border-gray-800">
                <td className="py-3 text-sm">
                  {new Date(threat.timestamp).toLocaleString()}
                </td>
                <td className="py-3">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    threat.type === 'SQL' ? 'bg-purple-500/20 text-purple-400' :
                    threat.type === 'XSS' ? 'bg-red-500/20 text-red-400' :
                    'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {threat.type}
                  </span>
                </td>
                <td className="py-3 font-mono text-sm">{threat.payload}</td>
                <td className="py-3">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    threat.status === 'Detected' ? 'bg-red-500/20 text-red-400' :
                    threat.status === 'Analyzing' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-green-500/20 text-green-400'
                  }`}>
                    {threat.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}