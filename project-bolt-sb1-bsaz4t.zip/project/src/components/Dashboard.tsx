import React, { useState } from 'react';
import { Shield, AlertTriangle, History } from 'lucide-react';
import type { Threat, Alert } from '../types';
import PayloadTester from './PayloadTester';
import AlertsList from './AlertsList';
import ThreatHistory from './ThreatHistory';
import { analyzePayload, createAlert } from '../utils/detection';

export default function Dashboard() {
  const [threats, setThreats] = useState<Threat[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);

  const handlePayloadSubmit = (payload: string) => {
    const threat = analyzePayload(payload);
    if (threat) {
      const alert = createAlert(threat);
      setThreats(prev => [threat, ...prev]);
      setAlerts(prev => [alert, ...prev]);
    }
  };

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-900/50 backdrop-blur p-6 rounded-xl border border-gray-800">
          <div className="flex items-center space-x-3">
            <Shield className="w-6 h-6 text-emerald-500" />
            <h3 className="text-lg font-semibold text-gray-200">System Status</h3>
          </div>
          <p className="mt-2 text-sm text-gray-400">Active - Monitoring Network</p>
          <div className="mt-4">
            <div className="w-full bg-gray-800 rounded-full h-2">
              <div className="bg-emerald-500 h-2 rounded-full w-3/4 transition-all duration-500"></div>
            </div>
          </div>
        </div>

        <div className="bg-gray-900/50 backdrop-blur p-6 rounded-xl border border-gray-800">
          <div className="flex items-center space-x-3">
            <AlertTriangle className="w-6 h-6 text-amber-500" />
            <h3 className="text-lg font-semibold text-gray-200">Active Threats</h3>
          </div>
          <p className="mt-2 text-2xl font-bold text-amber-500">{threats.length}</p>
        </div>

        <div className="bg-gray-900/50 backdrop-blur p-6 rounded-xl border border-gray-800">
          <div className="flex items-center space-x-3">
            <History className="w-6 h-6 text-blue-500" />
            <h3 className="text-lg font-semibold text-gray-200">Total Alerts</h3>
          </div>
          <p className="mt-2 text-2xl font-bold text-blue-500">{alerts.length}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PayloadTester onPayloadSubmit={handlePayloadSubmit} />
        <AlertsList alerts={alerts} />
      </div>

      <ThreatHistory threats={threats} />
    </div>
  );
}