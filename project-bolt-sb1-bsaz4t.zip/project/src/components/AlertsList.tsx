import React from 'react';
import { AlertTriangle } from 'lucide-react';
import type { Alert } from '../types';

interface AlertsListProps {
  alerts: Alert[];
}

export default function AlertsList({ alerts }: AlertsListProps) {
  return (
    <div className="bg-gray-900/50 backdrop-blur p-6 rounded-xl border border-gray-800">
      <h3 className="text-lg font-semibold text-gray-200 mb-4">Recent Alerts</h3>
      <div className="space-y-3">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className="flex items-start space-x-3 p-3 bg-gray-800/50 rounded-lg"
          >
            <AlertTriangle className={`w-5 h-5 ${
              alert.severity === 'high' ? 'text-red-500' :
              alert.severity === 'medium' ? 'text-amber-500' :
              'text-blue-500'
            }`} />
            <div>
              <p className="text-sm text-gray-300">{alert.message}</p>
              <p className="text-xs text-gray-500 mt-1">
                {new Date(alert.timestamp).toLocaleString()}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}