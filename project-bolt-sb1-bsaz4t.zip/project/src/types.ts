export interface Threat {
  id: string;
  timestamp: string;
  payload: string;
  type: 'SQL' | 'XSS' | 'Command';
  status: 'Detected' | 'Analyzing' | 'Cleared';
}

export interface Alert {
  id: string;
  timestamp: string;
  threatId: string;
  message: string;
  severity: 'high' | 'medium' | 'low';
}