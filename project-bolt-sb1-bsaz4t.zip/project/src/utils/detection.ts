import { Threat, Alert } from '../types';

const xssPatterns = [
  /<\s*script[^>]*>(.*?)<\s*\/\s*script\s*>/i,
  /javascript:/i,
  /on(load|click|mouseover|submit|focus|blur)="[^"]*"/i
];

const sqlPatterns = [
  /(\bUNION\b|\bSELECT\b|\bDROP\b|\bINSERT\b|\bDELETE\b|\bUPDATE\b|\bWHERE\b)/i,
  /'.*?'|\s+or\s+'.*?'='.*?'/i
];

const commandPatterns = [
  /[;&|`]|\$\([^)]*\)/i,
  /\b(cat|grep|echo|ls|pwd|sudo|wget|curl)\b/i
];

export const analyzePayload = (payload: string): Threat | null => {
  // Check for XSS
  if (xssPatterns.some(pattern => pattern.test(payload))) {
    return createThreat(payload, 'XSS');
  }
  
  // Check for SQL Injection
  if (sqlPatterns.some(pattern => pattern.test(payload))) {
    return createThreat(payload, 'SQL');
  }
  
  // Check for Command Injection
  if (commandPatterns.some(pattern => pattern.test(payload))) {
    return createThreat(payload, 'Command');
  }
  
  return null;
};

const createThreat = (payload: string, type: Threat['type']): Threat => ({
  id: Math.random().toString(36).substr(2, 9),
  timestamp: new Date().toISOString(),
  payload,
  type,
  status: 'Detected'
});

export const createAlert = (threat: Threat): Alert => ({
  id: Math.random().toString(36).substr(2, 9),
  timestamp: new Date().toISOString(),
  threatId: threat.id,
  message: `${threat.type} attack detected in payload`,
  severity: 'high'
});